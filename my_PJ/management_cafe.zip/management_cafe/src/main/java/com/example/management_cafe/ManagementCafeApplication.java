package com.example.management_cafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManagementCafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManagementCafeApplication.class, args);
	}

}
