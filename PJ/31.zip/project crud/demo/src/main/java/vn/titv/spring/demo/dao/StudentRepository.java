package vn.titv.spring.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;
import vn.titv.spring.demo.entity.Student;

@RepositoryRestResource(path = "students")
// child => childs XXXX
public interface StudentRepository extends JpaRepository<Student, Integer> {
    // Mo rong
    // ....
}
