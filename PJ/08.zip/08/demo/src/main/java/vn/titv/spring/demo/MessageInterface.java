package vn.titv.spring.demo;

public interface MessageInterface {
    public String sendMessage();
}
