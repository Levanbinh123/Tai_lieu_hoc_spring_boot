package vn.titv.spring.demo.exception;

public class SinhVienException extends RuntimeException{
    public SinhVienException(String message) {
        super(message);
    }

}
