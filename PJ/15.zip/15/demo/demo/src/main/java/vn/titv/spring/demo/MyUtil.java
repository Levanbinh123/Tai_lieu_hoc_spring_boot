package vn.titv.spring.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.lang.Math;

@Configuration
public class MyUtil {
    @Bean
    public Calculator getCalculator(){
        return new Calculator();
    }

    @Bean
    public Calculator getCalculator1(){
        return new Calculator();
    }

    @Bean
    public Calculator getCalculator2(){
        return new Calculator();
    }
}
