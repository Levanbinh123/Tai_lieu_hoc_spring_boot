package vn.titv.spring.demo;


// Day la mot Class cua don vi khac, khong the viet code o day
public class Calculator {

    public double canBacHai(double value){
        return Math.sqrt(value);
    }


    public double binhPhuong(double value){
        return Math.pow(value, 2);
    }
}
