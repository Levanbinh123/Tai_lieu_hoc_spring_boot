package vn.titv.spring.securityjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityjpaApplication.class, args);
	}

}
